# Readme

Full documentation on [MyJqueryPlugins](http://www.myjqueryplugins.com/jRating)

Demonstration on [jRating demonstration page](http://www.myjqueryplugins.com/jRating/demo)