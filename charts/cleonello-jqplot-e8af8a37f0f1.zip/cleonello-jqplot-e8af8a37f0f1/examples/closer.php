        </div>
<?php include "nav.php"; ?>
      </div>
    </div>
    <script type="text/javascript" src="example.js"></script>

</body>


</html>